package Clases;


import java.util.*;

/**
 * 
 */
public class Jugador extends Persona {

    public String nickname;
    public int nivelClasificatoria;
    public String contraseña;
    public String posicion;
    public int funcion;

    public Jugador() {
    }

    public Jugador(String nickname, int nivelClasificatoria, String contraseña, String posicion, int funcion, String cedula, String nombres, String apellidos) {
        super(cedula, nombres, apellidos);
        this.nickname = nickname;
        this.nivelClasificatoria = nivelClasificatoria;
        this.contraseña = contraseña;
        this.posicion = posicion;
        this.funcion = funcion;
    }

    




}