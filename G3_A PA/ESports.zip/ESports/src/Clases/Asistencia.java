package Clases;

import java.util.*;

/**
 *
 */
public class Asistencia {

    public Date fecha;

    public Asistencia() {
    }

    public Asistencia(Date fecha) {
        this.fecha = fecha;
    }

}
