package Clases;


import java.util.*;

/**
 * 
 */
public class Admin extends Persona {

    public String contraseña;
    
    public Admin() {
    }

    public Admin(String contraseña, String cedula, String nombres, String apellidos) {
        super(cedula, nombres, apellidos);
        this.contraseña = contraseña;
    }
     


}