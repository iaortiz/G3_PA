package Clases;

import java.util.*;

/**
 *
 */
public class Equipo {

    public String nombre;
    public Jugador jugadores;

    public Equipo() {
    }

    public Equipo(String nombre, Jugador jugadores) {
        this.nombre = nombre;
        this.jugadores = jugadores;
    }

    
}
