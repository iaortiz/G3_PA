package Clases;


import java.util.*;

/**
 * 
 */
public class Persona {

    public String cedula;
    public String nombres;
    public String apellidos;
    
    public Persona() {
    }

    public Persona(String cedula, String nombres, String apellidos) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
    }



}