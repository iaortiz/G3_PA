package Clases;


import java.util.*;

/**
 * 
 */
public class Coach extends Persona {

    public String contraseña;
    public int funcion;
    
    public Coach() {
    }

    public Coach(String contraseña, int funcion, String cedula, String nombres, String apellidos) {
        super(cedula, nombres, apellidos);
        this.contraseña = contraseña;
        this.funcion = funcion;
    }





}