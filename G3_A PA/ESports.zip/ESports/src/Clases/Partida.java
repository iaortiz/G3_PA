package Clases;

import java.util.*;

/**
 *
 */
public class Partida {

    public int muertes;
    public int asistencias;
    public int asesinatos;
    public int farm;

    public Partida() {
    }

    public Partida(int muertes, int asistencias, int asesinatos, int farm) {
        this.muertes = muertes;
        this.asistencias = asistencias;
        this.asesinatos = asesinatos;
        this.farm = farm;
    }
    
}
